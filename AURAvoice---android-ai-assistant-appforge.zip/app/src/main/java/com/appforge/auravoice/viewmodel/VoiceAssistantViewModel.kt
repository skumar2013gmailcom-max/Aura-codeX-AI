package com.appforge.auravoice.viewmodel

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.appforge.auravoice.router.CommandRouter
import com.appforge.auravoice.speech.TextToSpeechManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: Sender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis()
)

enum class Sender { USER, ASSISTANT, SYSTEM }

class VoiceAssistantViewModel : ViewModel() {

    private val _isListening = MutableStateFlow(false)
    val isListening: StateFlow<Boolean> = _isListening.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(
        listOf(
            ChatMessage(
                sender = Sender.ASSISTANT,
                text = "Hello! I am AuraVoice. Tap the microphone and speak a command or question."
            )
        )
    )
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    fun setListening(listening: Boolean) {
        _isListening.value = listening
    }

    fun onSpeechError(errorMessage: String) {
        _isListening.value = false
        addMessage(ChatMessage(sender = Sender.SYSTEM, text = "Speech recognition note: $errorMessage"))
    }

    fun processVoiceCommand(spokenText: String, context: Context, tts: TextToSpeechManager) {
        if (spokenText.isBlank()) return
        
        _isListening.value = false
        addMessage(ChatMessage(sender = Sender.USER, text = spokenText))

        viewModelScope.launch {
            val response = CommandRouter.execute(spokenText, context)
            addMessage(ChatMessage(sender = Sender.ASSISTANT, text = response))
            tts.speak(response)
        }
    }

    private fun addMessage(message: ChatMessage) {
        _messages.value = _messages.value + message
    }
}