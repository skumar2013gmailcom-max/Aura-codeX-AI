package com.appforge.auravoice.router

import android.content.Context
import android.content.Intent
import android.net.Uri
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object CommandRouter {

    fun execute(query: String, context: Context): String {
        val trimmed = query.trim().lowercase(Locale.getDefault())

        return when {
            // Time query
            trimmed.contains("what time") || trimmed.contains("current time") -> {
                val timeFormat = SimpleDateFormat("h:mm a", Locale.getDefault())
                "It is currently " + timeFormat.format(Date())
            }

            // Date query
            trimmed.contains("today's date") || trimmed.contains("what date") || trimmed.contains("what day is it") -> {
                val dateFormat = SimpleDateFormat("EEEE, MMMM d, yyyy", Locale.getDefault())
                "Today is " + dateFormat.format(Date())
            }

            // Web search intent
            trimmed.startsWith("search for ") || trimmed.startsWith("google ") -> {
                val searchTerm = query.substringAfter("search for ").substringAfter("google ")
                try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(searchTerm)))
                    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                    context.startActivity(intent)
                    "Searching Google for $searchTerm."
                } catch (e: Exception) {
                    "Could not open browser: " + e.localizedMessage
                }
            }

            // Open YouTube
            trimmed.contains("open youtube") -> {
                launchAppOrBrowser(context, "com.google.android.youtube", "https://youtube.com")
                "Opening YouTube."
            }

            // Open Maps
            trimmed.contains("open maps") || trimmed.contains("navigate") -> {
                launchAppOrBrowser(context, "com.google.android.apps.maps", "https://maps.google.com")
                "Opening Google Maps."
            }

            // General assistant queries
            trimmed.contains("who are you") || trimmed.contains("your name") -> {
                "I am AuraVoice, an autonomous native Android assistant built with AppForge AI!"
            }

            trimmed.contains("hello") || trimmed.contains("hi") -> {
                "Hello! How can I help you today? You can ask me the time, date, search Google, or open apps."
            }

            else -> {
                "I heard: \"$query\". You can ask me the time, date, search the web, or launch apps."
            }
        }
    }

    private fun launchAppOrBrowser(context: Context, packageName: String, fallbackUrl: String) {
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(packageName)
        if (launchIntent != null) {
            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(launchIntent)
        } else {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse(fallbackUrl))
            webIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(webIntent)
        }
    }
}