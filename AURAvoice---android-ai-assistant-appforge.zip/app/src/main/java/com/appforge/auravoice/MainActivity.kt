package com.appforge.auravoice

import android.Manifest
import android.content.pm.PackageManager
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import com.appforge.auravoice.speech.SpeechRecognitionManager
import com.appforge.auravoice.speech.TextToSpeechManager
import com.appforge.auravoice.ui.VoiceAssistantScreen
import com.appforge.auravoice.viewmodel.VoiceAssistantViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: VoiceAssistantViewModel by viewModels()
    private lateinit var speechManager: SpeechRecognitionManager
    private lateinit var ttsManager: TextToSpeechManager

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (isGranted) {
            speechManager.startListening()
        } else {
            Toast.makeText(this, "Microphone permission is required for voice commands", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Initialize Speech and TTS engines safely
        ttsManager = TextToSpeechManager(this)
        speechManager = SpeechRecognitionManager(
            context = this,
            onResult = { text -> viewModel.processVoiceCommand(text, this, ttsManager) },
            onError = { error -> viewModel.onSpeechError(error) },
            onListeningStateChanged = { isListening -> viewModel.setListening(isListening) }
        )

        setContent {
            VoiceAssistantScreen(
                viewModel = viewModel,
                onMicClick = { checkAndStartListening() }
            )
        }
    }

    private fun checkAndStartListening() {
        val permission = Manifest.permission.RECORD_AUDIO
        if (ContextCompat.checkSelfPermission(this, permission) == PackageManager.PERMISSION_GRANTED) {
            speechManager.startListening()
        } else {
            requestPermissionLauncher.launch(permission)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        speechManager.destroy()
        ttsManager.shutdown()
    }
}